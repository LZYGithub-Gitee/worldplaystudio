# Tranquillity Beta1.6

#### 介绍
Beta 1.6 of Tranquillity is online!
Fixed some bugs.


